# POD OS Classic Silver

A small Android launcher prototype inspired by the silver iPod Classic. It is
an independent project and is not affiliated with Apple.

## Current functions

- iPod-inspired silver body, monochrome menu screen and circular touch wheel.
- Swipe around the wheel to move through menu items; tap its centre to select.
- Music menu opens Android's document picker and plays a selected audio file.
- Play/Pause and Stop controls are included.
- Books menu passes a selected PDF, EPUB or text file to an installed Android
  reader app. Reading is handled by that app; this project does not contain
  its own PDF/EPUB rendering engine.
- Apps menu lists launchable non-system apps and opens the selected app.
- Settings menu links to Android's default-home settings.
- The app declares itself as both a launcher icon and a possible Home app.

## Not included yet

This is version 0.2.0, a functional prototype rather than a complete iPod
replacement. It does not include Cover Flow, synced playlists, a built-in
PDF/EPUB reader, album artwork management, or every physical iPod control.
The first APK is a debug build, not a Play Store release.

## Requirements

- Android Studio/Gradle build environment or GitHub Actions.
- JDK 17, Gradle 8.7, Android Gradle Plugin 8.6.1, Android SDK 35.
- Minimum supported Android version: Android 8.0 (API 26).

The project targets API 28 for this first iteration to keep compatibility with
older Android devices. It compiles against API 35.

## Build locally

From this folder, with Gradle 8.7 and Android SDK 35 installed:

```bash
gradle assembleDebug
```

The APK is generated at:

`app/build/outputs/apk/debug/app-debug.apk`

## Build with GitHub Actions (upload the project contents)

1. Extract the ZIP.
2. Upload the files and folders inside this project to the root of a GitHub
   repository, preserving their folder structure. The `app` folder and
   `.github/workflows/build-apk.yml` are required.
3. Commit to the `main` branch.
4. Open the repository's **Actions** tab. Select **Build POD OS Classic Silver
   APK** and choose **Run workflow**, or let the push trigger it.
5. Open the completed run and download the artifact named
   **POD-OS-Classic-Silver-APK**. Extract that artifact ZIP to find
   `app-debug.apk`.

If the mobile file picker does not show the hidden `.github` directory, use
GitHub's **Add file → Create new file** and create this exact path:

`.github/workflows/build-apk.yml`

Then paste the contents of the included `.github/workflows/build-apk.yml`.

## Upload only the ZIP (simpler file selection)

If your phone cannot upload folders, upload this project ZIP itself to the
repository root, keeping its filename as
`POD_OS_Classic_Silver_Complete_Project_v2.zip`. Then create a new file in GitHub
at `.github/workflows/build-apk.yml` with the workflow below. This workflow
unpacks the archive before building it:

```yaml
name: Build POD OS Classic Silver APK
on:
  workflow_dispatch:
  push:
    branches: [ main ]
permissions:
  contents: read
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v7
      - uses: actions/setup-java@v6
        with:
          distribution: temurin
          java-version: '17'
      - uses: android-actions/setup-android@v4
      - run: sdkmanager "platforms;android-35" "build-tools;35.0.0"
      - uses: gradle/actions/setup-gradle@v6
        with:
          gradle-version: '8.7'
      - name: Unpack project source
        run: unzip -q POD_OS_Classic_Silver_Complete_Project_v2.zip -d source
      - name: Build debug APK
        working-directory: source
        run: gradle --no-daemon --stacktrace assembleDebug
      - uses: actions/upload-artifact@v4
        with:
          name: POD-OS-Classic-Silver-APK
          path: source/app/build/outputs/apk/debug/app-debug.apk
          if-no-files-found: error
          retention-days: 7
```

## Choosing it as the default Home app

After installing the APK, press the phone's Home button. Select **POD OS
Classic Silver** and choose **Always** if Android offers that option. You can
also open the Settings item inside POD OS to open Android's Home-app settings.
If the device does not show it there, go to Android Settings and search for
"Default apps" or "Home app".

## Troubleshooting

- If Actions fails, open the failed workflow run and inspect the first red
  error. The build log is more useful than the final generic failure line.
- If an audio file will not play, try a common MP3 or M4A file.
- To open PDF/EPUB, the phone needs a compatible reader app installed.
- This first build has not been compiled on the target Huawei device yet;
  the GitHub Actions run must complete successfully before there is an APK.
