package com.podos.classicsilver;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/**
 * First functional POD OS Classic Silver launcher prototype.
 * It uses Android's document picker and media APIs, so it does not need
 * broad storage permissions. The visual design is inspired by classic iPods;
 * it is not Apple's software or an exact reproduction.
 */
public class MainActivity extends Activity {
    private IpodView ipodView;
    private MediaPlayer mediaPlayer;
    private String currentTrack = "Ninguna canción seleccionada";
    private boolean isPreparing = false;

    private enum Screen { HOME, MUSIC, BOOKS, APPS, NOW_PLAYING, SETTINGS }
    private Screen screen = Screen.HOME;
    private int selected = 0;
    private final List<AppEntry> apps = new ArrayList<>();
    private int appScroll = 0;
    private static final int PICK_AUDIO = 41;
    private static final int PICK_BOOK = 42;

    private static final String[] HOME_ITEMS = {
            "Music", "Books", "Apps", "Now Playing", "Settings"
    };
    private static final String[] MUSIC_ITEMS = {
            "Choose a song", "Play / Pause", "Stop", "Back"
    };
    private static final String[] BOOK_ITEMS = {
            "Open a book or PDF", "Back"
    };
    private static final String[] SETTINGS_ITEMS = {
            "Choose default launcher", "About POD OS", "Back"
    };
    private static final String[] NOW_ITEMS = {
            "Choose a song", "Play / Pause", "Back"
    };

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        ipodView = new IpodView();
        setContentView(ipodView);
        loadApps();
    }

    private void loadApps() {
        apps.clear();
        PackageManager pm = getPackageManager();
        List<ApplicationInfo> installed = pm.getInstalledApplications(0);
        for (ApplicationInfo info : installed) {
            if (!getPackageName().equals(info.packageName) && pm.getLaunchIntentForPackage(info.packageName) != null) {
                CharSequence label = pm.getApplicationLabel(info);
                apps.add(new AppEntry(label == null ? info.packageName : label.toString(), info.packageName));
            }
        }
        Collections.sort(apps, Comparator.comparing((AppEntry a) -> a.label.toLowerCase(Locale.ROOT)));
    }

    private String[] currentItems() {
        switch (screen) {
            case MUSIC: return MUSIC_ITEMS;
            case BOOKS: return BOOK_ITEMS;
            case SETTINGS: return SETTINGS_ITEMS;
            case NOW_PLAYING: return NOW_ITEMS;
            default: return HOME_ITEMS;
        }
    }

    private int itemCount() {
        if (screen == Screen.APPS) return Math.max(1, apps.size() + 1);
        return currentItems().length;
    }

    private String itemAt(int index) {
        if (screen == Screen.APPS) {
            if (index == apps.size()) return "Back";
            if (index < 0 || index >= apps.size()) return "";
            return apps.get(index).label;
        }
        String[] items = currentItems();
        return index >= 0 && index < items.length ? items[index] : "";
    }

    private void changeSelection(int amount) {
        int count = itemCount();
        if (count <= 0) return;
        if (screen == Screen.APPS && count > 7) {
            selected = (selected + amount + count) % count;
            if (selected < appScroll) appScroll = selected;
            if (selected >= appScroll + 5) appScroll = selected - 4;
        } else {
            selected = (selected + amount + count) % count;
        }
        ipodView.invalidate();
    }

    private void goBack() {
        if (screen == Screen.HOME) return;
        screen = Screen.HOME;
        selected = 0;
        appScroll = 0;
        ipodView.invalidate();
    }

    private void selectCurrent() {
        if (screen == Screen.HOME) {
            switch (selected) {
                case 0: screen = Screen.MUSIC; break;
                case 1: screen = Screen.BOOKS; break;
                case 2: screen = Screen.APPS; loadApps(); break;
                case 3: screen = Screen.NOW_PLAYING; break;
                case 4: screen = Screen.SETTINGS; break;
            }
            selected = 0;
        } else if (screen == Screen.MUSIC) {
            switch (selected) {
                case 0: pickAudio(); return;
                case 1: togglePlayback(); return;
                case 2: stopPlayback(); return;
                case 3: goBack(); return;
            }
        } else if (screen == Screen.BOOKS) {
            if (selected == 0) { pickBook(); return; }
            goBack(); return;
        } else if (screen == Screen.APPS) {
            if (selected == apps.size()) { goBack(); return; }
            launchApp(selected);
            return;
        } else if (screen == Screen.NOW_PLAYING) {
            if (selected == 0) { pickAudio(); return; }
            if (selected == 1) { togglePlayback(); return; }
            goBack(); return;
        } else if (screen == Screen.SETTINGS) {
            if (selected == 0) { openHomeSettings(); return; }
            if (selected == 1) {
                Toast.makeText(this, "POD OS Classic Silver · versión 0.2.0", Toast.LENGTH_LONG).show();
                return;
            }
            goBack(); return;
        }
        ipodView.invalidate();
    }

    private void pickAudio() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("audio/*");
        try { startActivityForResult(intent, PICK_AUDIO); }
        catch (ActivityNotFoundException ex) { toast("No se encontró un selector de archivos compatible."); }
    }

    private void pickBook() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        try { startActivityForResult(intent, PICK_BOOK); }
        catch (ActivityNotFoundException ex) { toast("No se encontró un selector de archivos compatible."); }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (requestCode == PICK_AUDIO) {
            startAudio(uri);
        } else if (requestCode == PICK_BOOK) {
            openBook(uri);
        }
    }

    private void startAudio(Uri uri) {
        releasePlayer();
        try {
            currentTrack = getName(uri);
            mediaPlayer = new MediaPlayer();
            mediaPlayer.setDataSource(this, uri);
            isPreparing = true;
            mediaPlayer.setOnPreparedListener(mp -> {
                isPreparing = false;
                mp.start();
                ipodView.invalidate();
                toast("Reproduciendo: " + currentTrack);
            });
            mediaPlayer.setOnCompletionListener(mp -> ipodView.invalidate());
            mediaPlayer.setOnErrorListener((mp, what, extra) -> {
                isPreparing = false;
                toast("No se pudo reproducir este archivo.");
                return true;
            });
            mediaPlayer.prepareAsync();
            ipodView.invalidate();
        } catch (IOException | IllegalStateException ex) {
            releasePlayer();
            toast("No se pudo abrir el archivo de audio.");
        }
    }

    private String getName(Uri uri) {
        String value = uri.getLastPathSegment();
        if (value == null || value.trim().isEmpty()) return "Archivo de audio";
        int slash = value.lastIndexOf('/');
        return slash >= 0 ? value.substring(slash + 1) : value;
    }

    private void openBook(Uri uri) {
        String path = getName(uri).toLowerCase(Locale.ROOT);
        String mime = "*/*";
        if (path.endsWith(".pdf")) mime = "application/pdf";
        else if (path.endsWith(".epub")) mime = "application/epub+zip";
        else if (path.endsWith(".txt")) mime = "text/plain";
        Intent view = new Intent(Intent.ACTION_VIEW);
        view.setDataAndType(uri, mime);
        view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try { startActivity(Intent.createChooser(view, "Abrir con")); }
        catch (ActivityNotFoundException ex) { toast("No hay una aplicación instalada para abrir este formato."); }
    }

    private void togglePlayback() {
        if (mediaPlayer == null) {
            toast("Primero elige una canción.");
            return;
        }
        if (isPreparing) { toast("Preparando la canción…"); return; }
        try {
            if (mediaPlayer.isPlaying()) mediaPlayer.pause();
            else mediaPlayer.start();
        } catch (IllegalStateException ex) {
            toast("No se puede controlar la reproducción ahora.");
        }
        ipodView.invalidate();
    }

    private void stopPlayback() {
        if (mediaPlayer != null) {
            try { mediaPlayer.pause(); mediaPlayer.seekTo(0); }
            catch (IllegalStateException ignored) { }
        }
        ipodView.invalidate();
    }

    private boolean isPlaying() {
        try { return mediaPlayer != null && mediaPlayer.isPlaying(); }
        catch (IllegalStateException ex) { return false; }
    }

    private void releasePlayer() {
        if (mediaPlayer != null) {
            try { mediaPlayer.release(); } catch (Exception ignored) { }
            mediaPlayer = null;
        }
        isPreparing = false;
    }

    private void launchApp(int index) {
        if (index < 0 || index >= apps.size()) return;
        Intent launch = getPackageManager().getLaunchIntentForPackage(apps.get(index).packageName);
        if (launch != null) {
            try { startActivity(launch); }
            catch (ActivityNotFoundException ex) { toast("No se pudo abrir esta aplicación."); }
        } else toast("Esta aplicación no tiene una pantalla de inicio.");
    }

    private void openHomeSettings() {
        try { startActivity(new Intent("android.settings.HOME_SETTINGS")); }
        catch (ActivityNotFoundException ex) {
            try { startActivity(new Intent(Settings.ACTION_SETTINGS)); }
            catch (ActivityNotFoundException ignored) { toast("Abre Ajustes para elegir la aplicación de inicio."); }
        }
    }

    private void handleMenuButton() {
        if (screen != Screen.HOME) goBack();
        else openHomeSettings();
    }

    private void toast(String message) { Toast.makeText(this, message, Toast.LENGTH_SHORT).show(); }

    @Override
    protected void onDestroy() {
        releasePlayer();
        super.onDestroy();
    }

    private static class AppEntry {
        final String label;
        final String packageName;
        AppEntry(String label, String packageName) { this.label = label; this.packageName = packageName; }
    }

    private class IpodView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF r = new RectF();
        private float scale, w, h, wheelCx, wheelCy, wheelRadius;
        private float downX, downY, lastAngle;
        private boolean trackingWheel = false;
        private boolean movedWheel = false;
        private long lastTick = 0;

        IpodView() {
            super(MainActivity.this);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            w = getWidth(); h = getHeight();
            scale = w / 390f;
            canvas.save();
            canvas.scale(scale, scale);
            float logicalH = h / scale;
            drawBody(canvas, logicalH);
            drawScreen(canvas, logicalH);
            drawWheel(canvas, logicalH);
            canvas.restore();
        }

        private void drawBody(Canvas c, float logicalH) {
            p.setShader(new LinearGradient(0, 0, 390, logicalH,
                    new int[]{0xFFE9EAEC, 0xFFB7BBC0, 0xFFE2E4E6}, null, Shader.TileMode.CLAMP));
            c.drawRect(0, 0, 390, logicalH, p);
            p.setShader(null);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1.2f); p.setColor(0xFF8B8E92);
            r.set(7, 7, 383, logicalH - 7); c.drawRoundRect(r, 28, 28, p);
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFF8D9297); p.setTextAlign(Paint.Align.CENTER); p.setTextSize(9);
            c.drawText("POD OS  •  CLASSIC SILVER", 195, logicalH - 16, p);
        }

        private void drawScreen(Canvas c, float logicalH) {
            float left = 30, top = 34, right = 360, bottom = logicalH * 0.405f;
            p.setColor(0xFF45494D); r.set(left - 3, top - 3, right + 3, bottom + 3); c.drawRoundRect(r, 9, 9, p);
            p.setShader(new LinearGradient(left, top, left, bottom,
                    new int[]{0xFFF9FAFA, 0xFFE8EAEB, 0xFFD8DADD}, null, Shader.TileMode.CLAMP));
            r.set(left, top, right, bottom); c.drawRoundRect(r, 6, 6, p); p.setShader(null);

            p.setColor(0xFF34383B); p.setTextAlign(Paint.Align.LEFT); p.setTextSize(21); p.setFakeBoldText(true);
            c.drawText("iPod", left + 13, top + 27, p);
            p.setFakeBoldText(false); p.setTextAlign(Paint.Align.RIGHT); p.setTextSize(11);
            c.drawText("▰", right - 12, top + 22, p);
            p.setColor(0xFF74787B); p.setStrokeWidth(1);
            c.drawLine(left + 8, top + 37, right - 8, top + 37, p);

            String title = screenTitle();
            p.setColor(0xFF292D30); p.setTextAlign(Paint.Align.LEFT); p.setTextSize(15); p.setFakeBoldText(true);
            c.drawText(title, left + 13, top + 59, p); p.setFakeBoldText(false);

            float listTop = top + 73;
            float rowH = 23;
            int maxRows = 5;
            int start = 0;
            if (screen == Screen.APPS && selected >= maxRows) start = Math.max(0, Math.min(appScroll, Math.max(0, itemCount() - maxRows)));
            int visible = Math.min(maxRows, Math.max(0, itemCount() - start));
            p.setTextSize(14); p.setTextAlign(Paint.Align.LEFT);
            for (int i = 0; i < visible; i++) {
                int idx = start + i;
                float y = listTop + i * rowH;
                if (idx == selected) {
                    p.setColor(0xFF737A80); r.set(left + 6, y - 17, right - 6, y + 5); c.drawRoundRect(r, 3, 3, p);
                    p.setColor(Color.WHITE);
                } else p.setColor(0xFF25292C);
                String label = itemAt(idx);
                if (label.length() > 29) label = label.substring(0, 27) + "…";
                c.drawText(label, left + 16, y, p);
                p.setColor(idx == selected ? Color.WHITE : 0xFF5A6065);
                p.setTextAlign(Paint.Align.RIGHT); c.drawText("›", right - 15, y, p); p.setTextAlign(Paint.Align.LEFT);
            }
            if (screen == Screen.NOW_PLAYING) {
                p.setColor(0xFF45494D); p.setTextSize(10); p.setTextAlign(Paint.Align.LEFT);
                String track = currentTrack.length() > 42 ? currentTrack.substring(0, 39) + "…" : currentTrack;
                c.drawText(track, left + 13, bottom - 10, p);
            }
        }

        private String screenTitle() {
            switch (screen) {
                case MUSIC: return "Music";
                case BOOKS: return "Books";
                case APPS: return "Apps";
                case NOW_PLAYING: return "Now Playing";
                case SETTINGS: return "Settings";
                default: return "Main Menu";
            }
        }

        private void drawWheel(Canvas c, float logicalH) {
            wheelCx = 195; wheelCy = logicalH * 0.715f;
            wheelRadius = Math.min(135, logicalH * 0.23f);
            float outer = wheelRadius + 4;
            p.setShader(new RadialGradient(wheelCx - 24, wheelCy - 32, outer * 1.45f,
                    new int[]{0xFFFFFFFF, 0xFFD6D9DC, 0xFF92979C}, null, Shader.TileMode.CLAMP));
            c.drawCircle(wheelCx, wheelCy, outer, p); p.setShader(null);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1.2f); p.setColor(0xFF9B9FA3);
            c.drawCircle(wheelCx, wheelCy, outer, p); p.setStyle(Paint.Style.FILL);
            p.setShader(new RadialGradient(wheelCx - 20, wheelCy - 28, wheelRadius,
                    new int[]{0xFFF7F8F8, 0xFFE2E4E6, 0xFFBFC3C6}, null, Shader.TileMode.CLAMP));
            c.drawCircle(wheelCx, wheelCy, wheelRadius, p); p.setShader(null);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1); p.setColor(0xFFB1B5B8);
            c.drawCircle(wheelCx, wheelCy, wheelRadius - 1, p); p.setStyle(Paint.Style.FILL);

            float labelSize = Math.max(11, wheelRadius * 0.105f);
            p.setColor(0xFF5A5F63); p.setTextAlign(Paint.Align.CENTER); p.setTextSize(labelSize); p.setFakeBoldText(true);
            c.drawText("MENU", wheelCx, wheelCy - wheelRadius * 0.70f, p);
            c.drawText("◀◀", wheelCx - wheelRadius * 0.70f, wheelCy + 4, p);
            c.drawText("▶❚❚", wheelCx + wheelRadius * 0.70f, wheelCy + 4, p);
            c.drawText("▶▶", wheelCx, wheelCy + wheelRadius * 0.73f, p);
            p.setFakeBoldText(false);

            float center = wheelRadius * 0.38f;
            p.setShader(new RadialGradient(wheelCx - 8, wheelCy - 10, center * 1.5f,
                    new int[]{0xFFE9EBED, 0xFFCCD0D3, 0xFFB5B9BD}, null, Shader.TileMode.CLAMP));
            c.drawCircle(wheelCx, wheelCy, center, p); p.setShader(null);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1); p.setColor(0xFFA8ADB1);
            c.drawCircle(wheelCx, wheelCy, center, p); p.setStyle(Paint.Style.FILL);
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            float x = event.getX() / scale;
            float y = event.getY() / scale;
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    downX = x; downY = y; movedWheel = false;
                    float dx = x - wheelCx, dy = y - wheelCy;
                    float dist = (float) Math.sqrt(dx * dx + dy * dy);
                    trackingWheel = dist < wheelRadius + 18;
                    if (trackingWheel) lastAngle = (float) Math.atan2(dy, dx);
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (trackingWheel) {
                        float dx2 = x - wheelCx, dy2 = y - wheelCy;
                        float radius2 = (float) Math.sqrt(dx2 * dx2 + dy2 * dy2);
                        if (radius2 < wheelRadius * 0.40f || radius2 > wheelRadius + 18) return true;
                        float angle = (float) Math.atan2(dy2, dx2);
                        float diff = angle - lastAngle;
                        while (diff > Math.PI) diff -= (float) (2 * Math.PI);
                        while (diff < -Math.PI) diff += (float) (2 * Math.PI);
                        float threshold = 0.20f;
                        if (Math.abs(diff) >= threshold) {
                            int steps = Math.max(1, Math.min(5, (int) (Math.abs(diff) / threshold)));
                            changeSelection(diff > 0 ? steps : -steps);
                            lastAngle = angle;
                            movedWheel = true;
                            lastTick = System.currentTimeMillis();
                        }
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                    if (trackingWheel) {
                        float dx3 = x - wheelCx, dy3 = y - wheelCy;
                        float dist3 = (float) Math.sqrt(dx3 * dx3 + dy3 * dy3);
                        if (!movedWheel && dist3 < wheelRadius * 0.38f) selectCurrent();
                        else if (!movedWheel && y < wheelCy - wheelRadius * 0.52f) handleMenuButton();
                        else if (!movedWheel && y > wheelCy + wheelRadius * 0.53f) togglePlayback();
                        else if (!movedWheel && x < wheelCx - wheelRadius * 0.5f) changeSelection(-1);
                        else if (!movedWheel && x > wheelCx + wheelRadius * 0.5f) changeSelection(1);
                    }
                    trackingWheel = false;
                    return true;
            }
            return true;
        }
    }
}
